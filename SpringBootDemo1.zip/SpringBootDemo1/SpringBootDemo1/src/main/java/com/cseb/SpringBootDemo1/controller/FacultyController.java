package com.cseb.SpringBootDemo1.controller;

import com.cseb.SpringBootDemo1.entity.Faculty;
import com.cseb.SpringBootDemo1.service.FacultyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class FacultyController {
    @Autowired
    private FacultyService facultyService;

    @PostMapping("/save")
    public Faculty save(@RequestBody Faculty faculty)
    {
        return facultyService.save(faculty);
    }

    @GetMapping("/fetchAll")
    public List<Faculty> fetchAll()
    {
        return facultyService.fetchAll();
    }

    @GetMapping("/fetchById/{id}")
    public Faculty fetchById(@PathVariable("id") Long facultyId)
    {
        return facultyService.fetchById(facultyId);
    }

    @DeleteMapping("/deleteById/{id}")
    public String deleteByFacultyId(@PathVariable("id") Long facultyId)
    {
        facultyService.deleteByFacultyId(facultyId);
        return "Success";
    }

    @PostMapping("/fetchByFacultyName")
    public List<Faculty> fetchByFacultyName(@RequestParam String name){
        return facultyService.fetchByFacultyName(name);
    }
    @PutMapping("/updateById/{id}")
    public Faculty updateFaculty(@PathVariable("id") Long facultyId, @RequestBody Faculty updatedFaculty) {
        // Call the service layer to update the faculty details
        return facultyService.updateFaculty(facultyId, updatedFaculty);
    }
}

