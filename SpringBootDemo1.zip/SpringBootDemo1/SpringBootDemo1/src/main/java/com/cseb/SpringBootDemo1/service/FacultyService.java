package com.cseb.SpringBootDemo1.service;
import com.cseb.SpringBootDemo1.entity.Faculty;

import java.util.List;

public interface FacultyService {
    Faculty save(Faculty faculty);

    List<Faculty> fetchAll();

    Faculty fetchById(Long facultyId);

    void deleteByFacultyId(Long facultyId);

    List<Faculty> fetchByFacultyName(String name);
    Faculty updateFaculty(Long facultyId, Faculty updatedFaculty);
}

